# Welcome to Retro Bowl 2
Retro Bowl 2 is an American style football game created by New Star Games. Are you ready to manage your dream team into victory? Be the boss of your NFL franchise, expand your roster, take care of your press duties to keep your team and fans happy. MORE UPDATES SOON!!!

# Subscribe To **Loser Boys** On youtube for Future updates and leaks Link Below:

https://www.youtube.com/channel/UCSjd2xkw3oG66hCDH9BZoWQ

# Future Updates 
#1 More Uniforms/Helments

#2 More Fields/Stadiums

#3 Emotes

#4 Levels/Tiers

